import Button from './Button';
import Input from './Input';
import FormControl from './FormControl';

export const Form = {
  Button,
  Input,
  FormControl,
};
