import { FormControl, FormControlProps } from '@mui/material';

export default function CustomFormControl(props: FormControlProps) {
  return <FormControl {...props} />;
}
